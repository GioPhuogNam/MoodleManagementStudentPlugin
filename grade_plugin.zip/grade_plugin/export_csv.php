<?php

require_once('../../config.php');
require_login();

// Get course ID from the POST data.
$courseid = optional_param('id', null, PARAM_INT);
//$courseid = 6;
// Get grade data for the selected course.
function get_grade_data($courseid) {
    global $DB;
    // Retrieve grade data for the specified course.
    $grade_data = array();
    // Retrieve usernames, first names, and last names.
    $sql = "    SELECT u.id, u.username,
                       concat_ws(' ', u.firstname, u.lastname) as studentname
                FROM {user} u
                JOIN {role_assignments} ra ON ra.userid = u.id
                JOIN {context} ctx ON ctx.id = ra.contextid
                JOIN {course} c ON c.id = ctx.instanceid
                WHERE c.id = :courseid
                AND ra.roleid = 5"; // Student role ID
    $users = $DB->get_records_sql($sql, ['courseid' => $courseid]);
    // Retrieve quiz grades.
    $quizzes = $DB->get_records('quiz', ['course' => $courseid]);
    foreach ($users as $user) {
        $grade_data[$user->id] = [
            'username' => $user->username,
            'studentname' => $user->studentname
        ];
        foreach ($quizzes as $quiz) {
            $grade = $DB->get_field('quiz_grades', 'grade', ['quiz' => $quiz->id, 'userid' => $user->id]);
            $grade_data[$user->id]['quiz_' . $quiz->name] = $grade !== false ? $grade : '-';
        }
    }

    return $grade_data;
}
$grade_data = get_grade_data($courseid);

// Define CSV filename.
$filename = 'grade_export_' . date('Ymd') . '.csv';

// Set headers to force download as CSV file.
header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="' . $filename . '"');

// Open output stream.
$output = fopen('php://output', 'w');

// Write CSV headers.
$my_header =  array('Mã số sinh viên ', 'Họ và tên sinh viên');
foreach ($grade_data[array_key_first($grade_data)] as $key => $value) {
    if (strpos($key, 'quiz_') !== false) {
        array_push($my_header,substr($key, 5) );
    }
}

fputcsv($output, $my_header);


// Write CSV data.
foreach ($grade_data as $user) {
    $row = array($user['username'], $user['studentname']);
    foreach ($user as $key => $value) {
        if (strpos($key, 'quiz_') !== false) {
            $row[] = $value;
        }
    }
    fputcsv($output, $row);
}

// Close output stream.
fclose($output);