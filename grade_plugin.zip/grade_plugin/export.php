<?php

require_once('../../../config.php');
require_login();


// Get course ID from the URL parameter.
$courseid = optional_param('id', null, PARAM_INT);

// Get grade data for the selected course.
function get_grade_data($courseid) {
    global $DB;

    // Retrieve grade data for the specified course.
    $grade_data = array();

    // Retrieve usernames, first names, and last names.
    $sql = "
            SELECT u.id, u.username,
                   concat_ws(' ', u.firstname, u.lastname) as studentname
            FROM {user} u
            JOIN {role_assignments} ra ON ra.userid = u.id
            JOIN {context} ctx ON ctx.id = ra.contextid
            JOIN {course} c ON c.id = ctx.instanceid
            WHERE c.id = :courseid
            AND ra.roleid = 5"; // Student role ID

    $users = $DB->get_records_sql($sql, ['courseid' => $courseid]);

    // Retrieve quiz grades.
    $quizzes = $DB->get_records('quiz', ['course' => $courseid]);

    foreach ($users as $user) {
        $grade_data[$user->id] = [
            'username' => $user->username,
            'studentname' => $user->studentname
        ];

        foreach ($quizzes as $quiz) {
            $grade = $DB->get_field('quiz_grades', 'grade', ['quiz' => $quiz->id, 'userid' => $user->id]);
            $grade_data[$user->id]['quiz_' . $quiz->id] = $grade !== false ? $grade : '-';
        }
    }

    return $grade_data;
}
$grade_data = get_grade_data($courseid);

// Print the page header.
echo $OUTPUT->header();

// Display the grade table.
echo '<h2>Grade Table</h2>';
echo '<table border="1px solid black" width="100%" cellpadding="5">';
echo '<thead>';
echo '<tr>';
echo '<th>Username</th>';
echo '<th>Student`s Name</th>';
// Display quiz names as columns.
foreach ($grade_data[array_key_first($grade_data)] as $key => $value) {
    if (strpos($key, 'quiz_') !== false) {
        echo '<th>' . substr($key, 5) . '</th>';
    }
}
echo '</tr>';
echo '</thead>';
echo '<tbody>';
foreach ($grade_data as $user) {
    echo '<tr>';
    echo '<td>' . $user['username'] . '</td>';
    echo '<td>' . $user['studentname'] . '</td>';
    foreach ($user as $key => $value) {
        if (strpos($key, 'quiz_') !== false) {
            echo '<td>' . $value . '</td>';
        }
    }
    echo '</tr>';
}
echo '</tbody>';
echo '</table>';

// Add export button.
echo '<form action="export.php" method="post">';
echo '<input type="hidden" name="courseid" value="' . $courseid . '">';
echo '<button type="submit">Export as CSV</button>';
echo '</form>';

// Print the page footer.
echo $OUTPUT->footer();
