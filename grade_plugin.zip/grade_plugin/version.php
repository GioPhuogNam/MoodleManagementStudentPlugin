<?php
defined('MOODLE_INTERNAL') || die();

$plugin->version   = 2024050201; // Version number.
$plugin->requires  = 2019111200; // Requires Moodle 3.8.
$plugin->component = 'local_grade_plugin';
