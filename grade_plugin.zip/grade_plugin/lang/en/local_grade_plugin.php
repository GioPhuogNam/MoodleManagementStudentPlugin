<?php

$string['pluginname'] = 'Điểm kiểm tra';