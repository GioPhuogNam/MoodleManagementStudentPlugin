<?php

global $OUTPUT, $PAGE, $USER, $COURSE;
require_once('../../config.php');
require_login();

echo $OUTPUT -> header();

$userid = $USER->id;
$courseid = optional_param('id', null, PARAM_INT);
if($courseid !== null){
    $course = get_course($courseid);
    $course_name = $course->fullname;
}
function get_grade_data($courseid) {
    global $DB;
    // Retrieve grade data for the specified course.
    $grade_data = array();
    // Retrieve usernames, first names, and last names.
    $sql = "    SELECT u.id, u.username,
                       concat_ws(' ', u.firstname, u.lastname) as studentname
                FROM {user} u
                JOIN {role_assignments} ra ON ra.userid = u.id
                JOIN {context} ctx ON ctx.id = ra.contextid
                JOIN {course} c ON c.id = ctx.instanceid
                WHERE c.id = :courseid
                AND ra.roleid = 5"; // Student role ID
    $users = $DB->get_records_sql($sql, ['courseid' => $courseid]);
    // Retrieve quiz grades.
    $quizzes = $DB->get_records('quiz', ['course' => $courseid]);
    foreach ($users as $user) {
        $grade_data[$user->id] = [
            'username' => $user->username,
            'studentname' => $user->studentname
        ];
        foreach ($quizzes as $quiz) {
            $grade = $DB->get_field('quiz_grades', 'grade', ['quiz' => $quiz->id, 'userid' => $user->id]);
            $grade_data[$user->id]['quiz_' . $quiz->name] = $grade !== false ? $grade : '-';
        }
    }

    return $grade_data;
}

$grade_pass = 5;

if (!is_null($courseid)) {
    // Get grade data for the selected course.
    $grade_data = get_grade_data($courseid);

    // Display the grade table.
    echo '<h2>' . 'Bảng điểm ' .$course_name .'</h2>';
    echo '<table border="1px solid black" cellpadding="5">';
    echo '<thead>';
    echo '<tr>';
    echo '<th>Mã số sinh viên</th>';
    echo '<th>Họ và tên sinh viên</th>';
    // Display quiz names as columns.
    foreach ($grade_data[array_key_first($grade_data)] as $key => $value) {
        if (strpos($key, 'quiz_') !== false) {
            echo '<th>' . substr($key, 5) . '</th>';
        }
    }
    echo '<th>Điểm trung bình </th>';
//    echo '<th>Đánh giá</th>';
    echo '</tr>';
    echo '</thead>';
    echo '<tbody>';
    foreach ($grade_data as $user) {
        echo '<tr>';
        echo '<td>' . $user['username'] . '</td>';
        echo '<td>' . $user['studentname'] . '</td>';
        $total_score = 0;
        $quiz_count = 0;
        foreach ($user as $key => $value) {
            if (strpos($key, 'quiz_') !== false) {
                echo '<td>' . $value . '</td>';
                if($value != '-'){
                    $total_score += (int)$value;
                    $quiz_count++;
                }
            }
        }
        // Calculate average score.
        $average_score = $quiz_count > 0 ? $total_score / $quiz_count : 0;
        echo '<td>'. $average_score . '</td>';
        // Determine status based on Grade Pass.

        $status = $average_score >= (int)$grade_pass ? 'Đạt' : 'Chưa đạt';

//        echo '<td>' . $status . '</td>';
        echo '</tr>';
    }
    echo '</tbody>';
    echo '</table>';

}

echo '</table>';

// Add export button.
echo '</br>';
echo '<form action="export_csv.php" method="post">';
echo '<input type="hidden" name="id" value="' . $courseid . '">';
echo '<button type="submit" class="btn btn-primary">Tải bảng điểm</button>';
echo '</form>';


echo $OUTPUT -> footer();
