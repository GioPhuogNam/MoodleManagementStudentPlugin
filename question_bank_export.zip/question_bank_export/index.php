<?php
global $OUTPUT, $CFG, $USER, $DB, $PAGE, $SITE, $COURSE;
require_once ('../../config.php');
require_once ($CFG->libdir.'/adminlib.php');

$path = optional_param('path','',PARAM_PATH);
$pageparams = [];
if ($path){
    $pageparams['path'] = $path;
}
// Thiết lập đường dẫn
$PAGE->set_url('/local/question_bank_export/index.php');
require_login();
// Thiết lập bố cục trang
$PAGE->set_pagelayout('standard');
// Thiết lập ngữ cảnh
$context = context_system::instance();
$PAGE->set_context($context);
// Thiết lập tiêu đề trang
$PAGE->set_title(get_string('pluginname', 'local_question_bank_export'));

// Hiển thị phần đầu trang
echo $OUTPUT -> header();


// Kiểm tra khả năng truy cạp của người dùng hiện tại
if(has_capability('local/question_bank_export:manage', context_system::instance())) {

    // Lấy id của người dùng hiện tại
    $userid = $USER->id;
    // Lấy id của khóa học hiện tại
    $courseid = optional_param('id', null, PARAM_INT);
    // Gửi id của khóa học lên session
    $_SESSION['courseid'] = $courseid;
    $courses = $DB->get_record('course', ['id' => $courseid]);
    $users = $DB->get_record('user', ['id' => $userid]);

    // Hiển thị câu chào mừng
    echo '<div class="alert alert-success" role="alert">Chào mừng '
        . mb_strtoupper($users->firstname) .
        ' đến với hệ thống in bảng câu hỏi của một bài kiểm tra trắc nghiệm</div>';

    //NỘI DUNG
    $question_categories = $DB->get_records('question_categories');
    //Hiển thị biểu mẫu cho phép sinh viên chọn loại ngân hàng câu hỏi có trong hệ thống
    echo '<h2> KHÓA HỌC: '.mb_strtoupper($courses->fullname).'</h2>';
    echo '<form action="question_bank_display.php" method="post">';
    echo '<lable for="qt_cg_id"> Chọn loại ngân hàng câu hỏi: </lable>';
    echo '<select name="qt_cg_id" id="qt_cg_id">';

    foreach ($question_categories as $question_category){
        echo '<option value="'. $question_category->id.'">' .$question_category->name. '</option>';
    }
    echo '</select>';
    echo '<p  style="font-style: revert">Hiển thị câu hỏi ở danh mục phụ (Subcategoris): 
            <input type="checkbox" name="include_sub" value="include_sub"></p>';
    echo '<br><br>';
    echo '<input type="submit" value="Submit">';
    echo'</form>';



} else {
    echo get_string('capability_error', 'local_quiz_export');
}
// Hiển thị phần cuối trang
echo $OUTPUT -> footer();