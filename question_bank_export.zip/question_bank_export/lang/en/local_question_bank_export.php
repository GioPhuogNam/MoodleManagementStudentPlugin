<?php

$string['pluginname']='Xuất ngân hàng câu hỏi';