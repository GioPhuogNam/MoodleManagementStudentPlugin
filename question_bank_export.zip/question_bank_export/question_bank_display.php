<?php
global $OUTPUT, $CFG, $USER, $DB, $PAGE, $SITE, $COURSE;
require_once ('../../config.php');
require_once ($CFG->libdir.'/adminlib.php');

$path = optional_param('path','',PARAM_PATH);
$pageparams = [];
if ($path){
    $pageparams['path'] = $path;
}
// Thiết lập đường dẫn
$PAGE->set_url('/local/question_bank_export/index.php');
require_login();
// Thiết lập bố cục trang
$PAGE->set_pagelayout('standard');
// Thiết lập ngữ cảnh
$context = context_system::instance();
$PAGE->set_context($context);
// Thiết lập tiêu đề trang
$PAGE->set_title(get_string('pluginname', 'local_question_bank_export'));

// Hiển thị phần đầu trang
echo $OUTPUT -> header();
// Kiểm tra xem có submit dữ liệu không
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Kiểm tra xem dữu liệu đã được gửi đến từ form chọn bài kiểm tra hay chưa
    if (isset($_POST['qt_cg_id'])) {
        if(isset($_POST['include_sub'])){
            $selectQuestionCategoryId = $_POST['qt_cg_id'];
            $_SESSION['qt_cg_id'] = $selectQuestionCategoryId;

            $answers = $DB->get_records('question_answers');
            $question_categories = $DB->get_record('question_categories',['id'=>$selectQuestionCategoryId]);
            $category_parents = $DB->get_records('question_categories',['parent'=>$selectQuestionCategoryId]);
            echo '<h2>Ngân hàng câu hỏi của: '.$question_categories->name.'</h2>';
            //echo '<h3>Chọn câu hỏi muốn dùng tạo bài kiểm tra: </h3>';
            echo '<form action="quiz_export.php" method="post">';
            echo '<ul style="list-style: none">';
            foreach ($category_parents as $category_parent){
                $subcategory = $category_parent->id;
                // Truy xuat cơ sở dữ liệu
                $sql = "
            select q.id as question_id,
                   q.name
                   q.questiontext,
                   qv.version
            from mdl_question q
                     join mdl_question_versions qv
                          on q.id = qv.questionid
                     join mdl_question_bank_entries qbe
                          on qv.questionbankentryid = qbe.id
                     join mdl_question_categories qc
                          on qc.id = qbe.questioncategoryid
            where qc.id = $subcategory
            and qv.version = 1
            ";
                $questions = $DB->get_records_sql($sql);
                $answers = $DB->get_records('question_answers');
                $question_categories = $DB->get_record('question_categories',['id'=>$selectQuestionCategoryId]);
                // Hiển thị ngân hàng câu hỏi
                foreach ($questions as $question) {
                    echo '<li>'.$question->name.'. '. strip_tags($question->questiontext) . '</li>';
                    echo '<ul>';
                    $choice = 'A';
                    foreach ($answers as $answer) {
                        if ($answer->question == $question->question_id) {
                            echo '<li style="list-style: none">' . $choice++ . ') ' . strip_tags($answer->answer) . '</li>';
                        }
                    }
                    echo '</ul>';
                    //echo '<p  style="font-style: revert">Chọn câu hỏi: <input type="checkbox" id="'.$question->question_id.'" name="" value="'.$question->questiontext.'"></p>';
                }
                echo '</ul>';


            }
            echo '<input type="submit" value="Submit">';
            echo '</form>';


        }else{
            $selectQuestionCategoryId = $_POST['qt_cg_id'];
            $_SESSION['qt_cg_id'] = $selectQuestionCategoryId;

            // Truy xuat cơ sở dữ liệu
            $sql = "
            select q.id as question_id,
                   q.name,
                   q.questiontext,
                   qv.version
            from mdl_question q
                     join mdl_question_versions qv
                          on q.id = qv.questionid
                     join mdl_question_bank_entries qbe
                          on qv.questionbankentryid = qbe.id
                     join mdl_question_categories qc
                          on qc.id = qbe.questioncategoryid
            where qc.id = $selectQuestionCategoryId
            and qv.version = 1
            ";
            $questions = $DB->get_records_sql($sql);
            $answers = $DB->get_records('question_answers');
            $question_categories = $DB->get_record('question_categories',['id'=>$selectQuestionCategoryId]);
            // Hiển thị ngân hàng câu hỏi
            echo '<h2>Ngân hàng câu hỏi của '.$question_categories->name.'</h2>';
            //echo '<h3>Chọn câu hỏi muốn tạo bài kiểm tra: </h3>';
            echo '<form action="export_to_doc.php" method="post">';
            echo '<ul style="list-style: none">';
            foreach ($questions as $question) {
                echo '<li>'.$question->name.'. ' . strip_tags($question->questiontext) . '</li>';
                echo '<ul>';
                $choice = 'A';
                foreach ($answers as $answer) {
                    if ($answer->question == $question->question_id) {
                        echo '<li style="list-style: none">' . $choice++ . ') ' . strip_tags($answer->answer) . '</li>';
                    }
                }
                echo '</ul>';
                //echo '<p  style="font-style: revert">Chọn câu hỏi: <input type="checkbox" id="'.$question->question_id.'" name="" value="'.$question->questiontext.'"></p>';
            }
            echo '</ul>';

            echo '<input type="submit" value="Submit">';
            echo '</form>';
        }

    }
}

// Hiển thị phần cuối trang
echo $OUTPUT -> footer();



