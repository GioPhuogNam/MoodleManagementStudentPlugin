<?php
function local_question_bank_export_extend_settings_navigation($settingsnav, $context) {
    global $CFG, $PAGE;

    // Chỉ thêm mục thiết lập này trên trang khóa học, những trang web khác không thêm được.
    if (!$PAGE->course or $PAGE->course->id == 1) {
        return;
    }

    // Chỉ người dùng đượ cấp quyền mới có thể xem được trang này.
    if (!has_capability('moodle/backup:backupcourse', context_course::instance($PAGE->course->id))) {
        return;
    }

    if ($settingnode = $settingsnav->find('courseadmin', navigation_node::TYPE_COURSE)) {
        $strfoo = get_string('pluginname', 'local_question_bank_export');
        $url = new moodle_url('/local/question_bank_export/index.php', array('id' => $PAGE->course->id));
        $foonode = navigation_node::create(
            $strfoo,
            $url,
            navigation_node::NODETYPE_LEAF,
            'question_bank_export',
            'question_bank_export',
            new pix_icon('t/addcontact', $strfoo)
        );
        if ($PAGE->url->compare($url, URL_MATCH_BASE)) {
            $foonode->make_active();
        }
        $settingnode->add_node($foonode);
    }
}
