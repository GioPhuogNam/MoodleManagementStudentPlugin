<?php
global $OUTPUT, $CFG, $USER, $DB, $PAGE, $SITE, $COURSE;
require_once ('../../config.php');
require_once __DIR__. '/vendor/autoload.php';


// Lấy id của bài kiểm tra (quiz) từ session
$selectedQuizId = $_SESSION['quizid'];
// Lấy id của khóa học từ session
$courseid = $_SESSION['courseid'];
$selectQuestionCategoryId= $_SESSION['qt_cg_id'];

// Truy xuat cơ sở dữ liệu
$sql = "
            select q.id as question_id,
                   q.questiontext,
                   qbe.questioncategoryid as question_cg_id,
                   qc.name as question_cg_name
            from mdl_question q
                     join mdl_question_bank_entries qbe
                          on q.id = qbe.id
                     join mdl_question_categories qc
                          on qc.id=qbe.questioncategoryid
            where questioncategoryid = $selectQuestionCategoryId
            group by question_id;
            ";
$answers = $DB->get_records('question_answers');
$question_categories = $DB->get_record('question_categories',['id'=>$selectQuestionCategoryId]);
$category_parents = $DB->get_records('question_categories',['parent'=>$selectQuestionCategoryId]);

$phpWord = new \PhpOffice\PhpWord\PhpWord();
$section = $phpWord-> addSection();
$pageCount = count($phpWord->getSections());

foreach ($category_parents as $category_parent){
    $subcategory = $category_parent->id;
    $sql = "
            select q.id as question_id,
                   q.name,
                   q.questiontext,
                   qv.version
            from mdl_question q
                     join mdl_question_versions qv
                          on q.id = qv.questionid
                     join mdl_question_bank_entries qbe
                          on qv.questionbankentryid = qbe.id
                     join mdl_question_categories qc
                          on qc.id = qbe.questioncategoryid
            where qc.id = $subcategory
            and qv.version = 1
            ";
    $questions = $DB->get_records_sql($sql);
    $count=count($questions);
    $answers = $DB->get_records('question_answers');
    $question_categories = $DB->get_record('question_categories',['id'=>$selectQuestionCategoryId]);
// Hiển thị ngân hàng câu hỏi
    $section->addText(
        'Ngân hàng câu hỏi của '.$question_categories->name,
        array('name'=>'Times New Roman','size'=>16, 'bold'=>true),
        array('align'=>'center')
    );
    $section->addText(
        '(Ngân hàng gồm '.$count.' câu hỏi.)',
        array('name'=>'Times New Roman','size'=>12),
        array('align'=>'center')
    );
    foreach ($questions as $question) {
        $section->addText(
            $question->name.'. '.
            strip_tags($question->questiontext),
            array('name'=>'Times New Roman','size'=>12),
            array('align'=>'left')
        );
        $choice='A';
        foreach ($answers as $answer){
            if($answer->question == $question->question_id){
                $section->addText(
                    $choice++ . ') ' .strip_tags($answer->answer),
                    array('name'=>'Times New Roman','size'=>12),
                    array('indentation'=>array('left'=>400))
                );
            }
        }
    }
    $section->addTextBreak(2);
    $section->addText(
        '(Hết)',
        array('name'=>'Times New Roman','size'=>12,'bold'=>true),
        array('align'=>'center')
    );
}


header('Content-Type: application/vnd.ms-word');
header('Content-Disposition:attachment; filename="question_bank.pdf"');

$objWriter = \PhpOffice\PhpWord\IOFactory::createWriter($phpWord, 'Word2007');
$objWriter->save('php://output');;

