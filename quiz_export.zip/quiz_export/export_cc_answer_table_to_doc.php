<?php
global $OUTPUT, $CFG, $USER, $DB, $PAGE, $SITE, $COURSE;

require_once ('../../config.php');
require_once __DIR__. '/vendor/autoload.php';

// Lấy id của bài kiểm tra (quiz) từ session
$selectedQuizId = $_SESSION['quizid'];
// Lấy id của khóa học từ session
$courseid = $_SESSION['courseid'];
// Truy vấn bảng question, question_attemts, quiz_attemts, quiz để lấy dữ liệu về câu hỏi từ quiz.
$sql = "select
                    qt.questiontext, qt.id,qt.name
                from
                    mdl_question as qt
                join mdl_question_attempts as qat
                on qt.id = qat.questionid
                join mdl_quiz_attempts as qzat
                on qzat.uniqueid = qat.questionusageid
                join mdl_quiz as qz
                on qz.id = qzat.quiz
                where qz.id = $selectedQuizId
                group by qt.id
        ";

$questions = $DB->get_records_sql($sql);
// Truy vấn bảng answer để lấy câu trả lời
$answers = $DB->get_records('question_answers');
// Truy vấn bảng quiz để lấy thông tin về quiz
$quizzes= $DB->get_record('quiz', ['id' => $selectedQuizId]);
//Truy vấn bảng course để lấy thông tin về khóa học
$courses = $DB->get_record('course',['id'=>$courseid]);
// Đếm số câu hỏi có trong bài kiểm tra (quiz)
$count=count($questions);

$phpWord = new \PhpOffice\PhpWord\PhpWord();
$section = $phpWord-> addSection();

$section->addText(
    'KHÓA HỌC: '.mb_strtoupper($courses->fullname),
    array('name'=>'Times New Roman','size'=>12, 'bold'=>true),
    array('align'=>'center')
);
$section->addText(
    'BẢNG ĐÁP ÁN: '.mb_strtoupper($quizzes->name),
    array('name'=>'Times New Roman','size'=>12, 'bold'=>true),
    array('align'=>'center')
);
$table = $section->addTable(
    array(
        'borderSize'=>6,
    )
);

$table ->addRow(500);
$table->addCell(7000)->addText('Câu hỏi:',
    array('name'=>'Times New Roman','size'=>12, 'bold'=>true),
    array('align'=>'center'),
);
$table->addCell(500)->addText('A',
    array('name'=>'Times New Roman','size'=>12, 'bold'=>true),
    array('align'=>'center')
);
$table->addCell(500)->addText('B',
    array('name'=>'Times New Roman','size'=>12, 'bold'=>true),
    array('align'=>'center')
);
$table->addCell(500)->addText('C',
    array('name'=>'Times New Roman','size'=>12, 'bold'=>true),
    array('align'=>'center')
);
$table->addCell(500)->addText('D',
    array('name'=>'Times New Roman','size'=>12, 'bold'=>true),
    array('align'=>'center')
);

foreach ($questions as $question) {
    $table->addRow(500);
    $table->addCell(7000)->addText(strip_tags($question->name),
        array('name'=>'Times New Roman','size'=>12),
        array('align'=>'left')
    );
    foreach ($answers as $answer){
        if($answer->question == $question->id){
            if($answer->fraction == 1){
                $table->addCell(500)->addText('X',
                    array('name'=>'Times New Roman','size'=>12, 'bold'=>true),
                    array('align'=>'center')
                );
            }
            else {
                $table->addCell(500)->addText('');
            }
        }
    }
}



header('Content-Type: application/vnd.ms-word');
header('Content-Disposition:attachment; filename="quiz_correct_answer.docx"');

$objWriter = \PhpOffice\PhpWord\IOFactory::createWriter($phpWord, 'Word2007');
$objWriter->save('php://output');;
