<?php

defined('MOODLE_INTERNAL') || die();

$plugin->version = 2024041900;
$plugin->requires = 2021070100;
$plugin->component = 'local_quiz_export';
$plugin->release = '1.0.0';
$plugin->maturity = MATURITY_STABLE;
//$plugin->dependencies = array('phpoffice'=>ANY_VERSION);