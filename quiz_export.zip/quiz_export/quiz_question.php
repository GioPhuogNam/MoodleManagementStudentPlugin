<?php
global $OUTPUT, $CFG, $USER, $DB, $PAGE, $SITE, $COURSE;
require_once ('../../config.php');
require_once ($CFG->libdir.'/adminlib.php');

$path = optional_param('path','',PARAM_PATH);
$pageparams = [];
if ($path){
    $pageparams['path'] = $path;
}
// Thiết lập đường dẫn
$PAGE->set_url('/local/quiz_export/quiz_question.php');
require_login();
// Thiết lập bố cục trang
$PAGE->set_pagelayout('plugin');
// Thiết lập ngữ cảnh
$context = context_system::instance();
$PAGE->set_context($context);
// Thiết lập tiêu đề trang
$PAGE->set_title(get_string('pluginname', 'local_quiz_export'));

// Hiển thị phần đầu trang
echo $OUTPUT -> header();

// Liên kết đến tệp CSS để tùy chỉnh giao diện
echo '<link rel="stylesheet" type="text/css" href="styles.css">';

// Kiểm tra xem có submit dữ liệu không
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Kiểm tra xem dữu liệu đã được gửi đến từ form chọn bài kiểm tra hay chưa
    if (isset($_POST['quizid'])) {
        $selectedQuizId = $_POST['quizid'];
        // Lấy id của khóa học từ session
        $courseid = $_SESSION['courseid'];
        // Gửi id của bài kiểm tra lên session
        $quizid = $selectedQuizId;
        $_SESSION['quizid'] = $quizid;
        // Truy vấn bảng question, question_attemts, quiz_attemts, quiz để lấy dữ liệu về câu hỏi từ quiz.
        $sql = "select
                    qt.questiontext, qt.id, qt.name
                from
                    mdl_question as qt
                join mdl_question_attempts as qat
                on qt.id = qat.questionid
                join mdl_quiz_attempts as qzat
                on qzat.uniqueid = qat.questionusageid
                join mdl_quiz as qz
                on qz.id = qzat.quiz
                where qz.id = $selectedQuizId
                group by qt.id
        ";

        $questions = $DB->get_records_sql($sql);
        // Truy vấn bảng answer để lấy câu trả lời
        $answers = $DB->get_records('question_answers');
        // Truy vấn bảng quiz để lấy thông tin về quiz
        $quizzes= $DB->get_record('quiz', ['id' => $selectedQuizId]);
        //Truy vấn bảng course để lấy thông tin về khóa học
        $courses = $DB->get_record('course',['id'=>$courseid]);

        echo '<h2  class="text-center"> NỘI DUNG BÀI KIỂM TRA : '.mb_strtoupper($quizzes->name).'</h2>';
        echo '<ul style="list-style: none">';
        echo '<br>';
        foreach ($questions as $question) {
            echo '<li>'.$question->name.'. ' . strip_tags($question->questiontext) . '</li>';
            echo '<ul>';
            $choice='A';
            foreach ($answers as $answer){
                if($answer->question == $question->id){
                    echo '<li style="list-style: none">' .$choice++ . ') ' .strip_tags($answer->answer). '</li>';
                }
            }
            echo '</ul>';
        }
        echo '</ul>';
        echo '<hr>';
        echo '<h5  class="text-center">(Hết)</h5>';

        // Bảng đáp án
        echo '<h2>BẢNG ĐÁP ÁN : '.mb_strtoupper($quizzes->name).' </h2>';
        echo '<table class="table table-bordered mx-auto">';
        echo '<tr class="text-center">
                <th>Câu hỏi:</th>
                <th>A</th>
                <th>B</th>
                <th>C</th>
                <th>D</th>
                ';
        foreach ($questions as $question) {
            echo '<tr>';
            echo '<td>' . $question->name . '</td>';
            foreach ($answers as $answer){
                if($answer->question == $question->id){
                    if($answer->fraction == 1){
                        echo '<td class="text-center text-danger">X</td>';
                    }
                    else {
                        echo '<td></td>';
                    }
                }
            }

            echo '</tr>';
        }

        echo '</table>';
        echo '<br><br>';
        // Hiển thị button cho phép in câu hỏi và bảng đáp án
        echo html_writer::link(new moodle_url('export_quiz_question.php'), 'In câu hỏi', array('class' => 'btn btn-primary', 'style'=> 'margin: 5px'));
        echo html_writer::link(new moodle_url('export_quiz_correct_answer_table.php'), 'In bảng đáp án', array('class' => 'btn btn-primary', 'style'=> 'margin: 5px'));
        echo html_writer::link(new moodle_url('export_all.php'), 'In toàn bộ câu hỏi và bảng đáp án', array('class' => 'btn btn-primary', 'style'=> 'margin: 5px'));

    }
}


// Hiển thị phần cuối trang
echo $OUTPUT -> footer();


