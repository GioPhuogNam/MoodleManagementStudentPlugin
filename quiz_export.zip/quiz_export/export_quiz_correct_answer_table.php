<?php
global $OUTPUT, $CFG, $USER, $DB, $PAGE, $SITE, $COURSE;
require_once ('../../config.php');
require_once ($CFG->libdir.'/adminlib.php');

$path = optional_param('path','',PARAM_PATH);
$pageparams = [];
if ($path){
    $pageparams['path'] = $path;
}
// Thiết lập đường dẫn
$PAGE->set_url('/local/quiz_export/export_quiz_correct_answer_table.php');
require_login();
// Thiết lập bố cục trang
$PAGE->set_pagelayout('plugin');
// Thiết lập ngữ cảnh
$context = context_system::instance();
$PAGE->set_context($context);
// Thiết lập tiêu đề trang
$PAGE->set_title(get_string('pluginname', 'local_quiz_export'));

// Hiển thị phần đầu trang
echo $OUTPUT -> header();

// Liên kết đến tệp CSS để tùy chỉnh giao diện
echo '<link rel="stylesheet" type="text/css" href="styles.css">';

// Lấy id của bài kiểm tra (quiz) từ session
$selectedQuizId = $_SESSION['quizid'];
// Lấy id của khóa học từ session
$courseid = $_SESSION['courseid'];
// Truy vấn bảng question, question_attemts, quiz_attemts, quiz để lấy dữ liệu về câu hỏi từ quiz.
$sql = "select
                    qt.questiontext, qt.id, qt.name
                from
                    mdl_question as qt
                join mdl_question_attempts as qat
                on qt.id = qat.questionid
                join mdl_quiz_attempts as qzat
                on qzat.uniqueid = qat.questionusageid
                join mdl_quiz as qz
                on qz.id = qzat.quiz
                where qz.id = $selectedQuizId
                group by qt.id
        ";

$questions = $DB->get_records_sql($sql);
// Truy vấn bảng answer để lấy câu trả lời
$answers = $DB->get_records('question_answers');
// Truy vấn bảng quiz để lấy thông tin về quiz
$quizzes= $DB->get_record('quiz', ['id' => $selectedQuizId]);
//Truy vấn bảng course để lấy thông tin về khóa học
$courses = $DB->get_record('course',['id'=>$courseid]);

// Bảng đáp án
echo '<h2>KHÓA HỌC: ' .mb_strtoupper($courses->fullname) .' </h2>';
echo '<h2>BẢNG ĐÁP ÁN: '.mb_strtoupper($quizzes->name).' </h2>';
echo '<table class="table table-bordered mx-auto">';
echo '<tr class="text-center">
                <th>Câu hỏi:</th>
                <th>A</th>
                <th>B</th>
                <th>C</th>
                <th>D</th>
                ';
foreach ($questions as $question) {
    echo '<tr>';
    echo '<td>'.$question->name . '</td>';
    foreach ($answers as $answer){
        if($answer->question == $question->id){
            if($answer->fraction == 1){
                echo '<td class="text-center text-black-50">X</td>';
            }
            else {
                echo '<td></td>';
            }
        }
    }

    echo '</tr>';
}

echo '</table>';

// Tạo một button cho phép xuất trang với định dạng word
echo '<form action="export_cc_answer_table_to_doc.php" method="post">';
echo '<input type="submit" value="Export" class="btn btn-primary">';
echo '</form>';

// Hiển thị phần cuối trang
echo $OUTPUT -> footer();


