<?php
$string['pluginname']= 'In bài kiểm tra';
$string['capability_error'] = 'Bạn không có quyền truy cập vào trang này';