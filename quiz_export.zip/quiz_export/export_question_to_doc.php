<?php
global $OUTPUT, $CFG, $USER, $DB, $PAGE, $SITE, $COURSE;
require_once ('../../config.php');
require_once __DIR__. '/vendor/autoload.php';


// Lấy id của bài kiểm tra (quiz) từ session
$selectedQuizId = $_SESSION['quizid'];
// Lấy id của khóa học từ session
$courseid = $_SESSION['courseid'];
// Truy vấn bảng question, question_attemts, quiz_attemts, quiz để lấy dữ liệu về câu hỏi từ quiz.
$sql = "select
                    qt.questiontext, qt.id,qt.name
                from
                    mdl_question as qt
                join mdl_question_attempts as qat
                on qt.id = qat.questionid
                join mdl_quiz_attempts as qzat
                on qzat.uniqueid = qat.questionusageid
                join mdl_quiz as qz
                on qz.id = qzat.quiz
                where qz.id = $selectedQuizId
                group by qt.id
        ";

$questions = $DB->get_records_sql($sql);
// Truy vấn bảng answer để lấy câu trả lời
$answers = $DB->get_records('question_answers');
// Truy vấn bảng quiz để lấy thông tin về quiz
$quizzes= $DB->get_record('quiz', ['id' => $selectedQuizId]);
//Truy vấn bảng course để lấy thông tin về khóa học
$courses = $DB->get_record('course',['id'=>$courseid]);
// Đếm số câu hỏi có trong bài kiểm tra (quiz)
$count=count($questions);

$phpWord = new \PhpOffice\PhpWord\PhpWord();
$section = $phpWord-> addSection();
$pageCount = count($phpWord->getSections());
$styleTable = array(
    'borderColor'=>'#FFFFFF',
    'borderSize'=> 0,
);
$phpWord->addTableStyle('myTable', $styleTable);
$table = $section->addTable('myTable');
$table->addRow(2000);
$cell1 = $table->addCell(5300);
$textBox1 = $cell1->addTextBox(
    array(
        'width' =>260,
        'height'=> 100,
        'borderSize'=>0,
        'borderColor'=>'#FFFFFF'

    )
);
$textBox1->addText(
    'TRƯỜNG ĐẠI HỌC CẦN THƠ',
    array('name'=>'Times New Roman','size'=>12, 'bold'=>true),
    array('align'=>'center')
);$textBox1->addText(
    'TRƯỜNG CÔNG NGHỆ THÔNG TIN VÀ TT',
    array('name'=>'Times New Roman','size'=>12, 'bold'=>true),
    array('align'=>'center')
);$textBox1->addText(
    'KHOA MẠNG MÁY TÍNH VÀ TT',
    array('name'=>'Times New Roman','size'=>12, 'bold'=>true),
    array('align'=>'center')
);
$cell2 = $table->addCell(4700);
$textBox2 = $cell2->addTextBox(
    array(
        'width' =>240,
        'height'=> 100
    )
);
$textBox2 -> addText(
    'ĐỀ THI '. mb_strtoupper($courses->fullname, "UTF-8" ),
    array('name'=>'Times New Roman','size'=>12, 'bold'=>true),
    array('align'=>'left')
);
$textBox2->addText(
    'HỌC KỲ __ /20____ - 20____',
    array('name'=>'Times New Roman','size'=>12),
    array('align'=>'left')
);
$textBox2->addText(
    'Ngày thi: __/__/_____',
    array('name'=>'Times New Roman','size'=>12),
    array('align'=>'left')
);
$textBox2->addText(
    'Thời gian làm bài: '.(int)$quizzes->timelimit/60 .' phút',
    array('name'=>'Times New Roman','size'=>12),
    array('align'=>'left')
);

$section ->addText(
    'NỘI DUNG ĐỀ THI',
    array('name'=>'Times New Roman','size'=>12,'bold'=>true),
    array('align'=>'center')
);
$section->addText(
    '(Đề thi gồm '.$count.' câu hỏi được in trên '.$pageCount.'trang giấy)',
    array('name'=>'Times New Roman','size'=>12),
    array('align'=>'center')
);

foreach ($questions as $question) {
     $section->addText($question->name.'. '.
         strip_tags($question->questiontext),
         array('name'=>'Times New Roman','size'=>12),
         array('align'=>'left')
     );
    $choice='A';
    foreach ($answers as $answer){
        if($answer->question == $question->id){
            $section->addText(
                $choice++ . ') ' .strip_tags($answer->answer),
               array('name'=>'Times New Roman','size'=>12),
                array('indentation'=>array('left'=>400))
            );
        }
    }
}
$section->addTextBreak(2);
$section->addText(
    '(Hết)',
    array('name'=>'Times New Roman','size'=>12,'bold'=>true),
    array('align'=>'center')
);
header('Content-Type: application/vnd.ms-word');
header('Content-Disposition:attachment; filename="quiz_question.docx"');

$objWriter = \PhpOffice\PhpWord\IOFactory::createWriter($phpWord, 'Word2007');
$objWriter->save('php://output');;